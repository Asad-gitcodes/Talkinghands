exports.getClustering = (req, res) => {
  res.render('clustering');
};